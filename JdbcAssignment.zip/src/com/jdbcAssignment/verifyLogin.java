package com.jdbcAssignment;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class verifyLogin
 */
@WebServlet("/verifyLogin")
public class verifyLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		Insert in = new Insert();
		con = in.commonCon(config);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		

		try {
			String sql = "select * from employee where email=? AND password=? AND is_active=? LIMIT 1";
			
			PreparedStatement stmt = con.prepareStatement(sql);
			
			
			stmt.setString(1, email);
			stmt.setString(2, password);
			stmt.setInt(3, 1);
			
			ResultSet result = stmt.executeQuery();
			
			if (result.next()) 
			{
				String output="<html lang=en> <head> <meta charset=UTF-8/> <meta name=viewport content=width=device-width, initial-scale=1.0/> "
						+ "<title>Document</title> "
						+ "</head> "
						+ "<body> "
						+ "<table  border=1> "
						
						+ "<tr> "
						+ "<th>Name</th> "
						+ "<td>"+result.getString(2)+"</td>"
						+ "</tr>"
						+ ""
						+ "<tr> <th>Email</th> <td>"+result.getString(3)+"</td></tr>"
						+ ""
						+ "<tr> <th>Password</th> <td>"+result.getString(4)+"</td></tr>"
						+ ""
						+ "<tr> <th>Date Of Birth</th> <td>"+result.getDate(5)+"</td></tr>"
						+ ""
						+ "<tr> <td colspan=2> <button><a href=update?id="+result.getInt(1)+">Update</a></button ><button><a href=delete?id="+result.getInt(1)+">Delete</a></button> </td></tr>"
						+ ""
						+ "</table> "
						+ "</body>"
						+ "</html>";
				out.print(output);
			} 
			else {
				out.print("Wrong Credentials");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
