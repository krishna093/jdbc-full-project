package com.jdbcAssignment;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Insert
 */
@WebServlet("/Insert")
public class Insert extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection connect;
	private String sql;
       
   
	public void init(ServletConfig config) throws ServletException {
		
		 connect = commonCon(config);
		
		
		
		
		
	}
	
	// Method for Common Connection in all servlets
	public  Connection commonCon(ServletConfig config) throws ServletException
	{
		Connection con=null;
		ServletContext context = config.getServletContext();
		try 
		{
			Class.forName(context.getInitParameter("className"));
			con = DriverManager.getConnection(context.getInitParameter("dburl"), 
										context.getInitParameter("dbUser"),
										context.getInitParameter("dbPassword"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}


	// fetching all values from html
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		int id = 0;
		try {
		id= Integer.parseInt(req.getParameter("id"));
		}
		catch(Exception e)
		{
			//System.out.println();
		}
		String name = req.getParameter("username");
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		String cpassword= req.getParameter("password_confirm");
		String dob=req.getParameter("dob");
		String reqType=req.getParameter("submit");
		Date parseDate = null;
		try {
			parseDate = new SimpleDateFormat("yyyy-MM-dd").parse(dob);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		java.sql.Date realDob = new java.sql.Date(parseDate.getTime());
		
		if(password.equals(cpassword))
		{
			if(reqType.equals("Register")) {
				 sql="insert into employee(name,email,password,dob)Values(?,?,?,?)";
			}
			else if(reqType.equals("Update"))
			{
				sql = "update employee SET name=?, email=?,password=?,dob=? where pk_id=?";
			}
			try 
			{
				//Create a statement using connection object
				
				PreparedStatement stmt = connect.prepareStatement(sql);
				stmt.setString(1, name);
				stmt.setString(2, email);
				stmt.setString(3, password);
				stmt.setDate(4, realDob);
				if(reqType.equals("Update"))
				{
					stmt.setInt(5, id);
				}
				
				int result = stmt.executeUpdate();
				if(result>0)
				{
					res.setContentType("text/html");
					PrintWriter out = res.getWriter();
					if(reqType.equals("Register"))
						out.println("<h3>Registration Successful</h3>");
					else if(reqType.equals("Update"))
						out.println("<h3>Updated Successful</h3>");
					
				}
			} 
			
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
	public void destroy() {
		
	}
}
